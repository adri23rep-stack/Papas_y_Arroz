Nova MotionBoost RIFE GPU Vulkan (experimental add-on)
Source: styler00dollar/VapourSynth-RIFE-ncnn-Vulkan r9_mod_v33
Model: RIFE v4.6, MIT licensed plugin with upstream model licenses.
Requires a Vulkan-capable GPU and working NVIDIA/AMD/Intel drivers.
Place this add-on in the SAME folder as the Nova Qt + playback addon.
The big Python runtime belongs in nova-gpu/python and is only used for RIFE.
Nova will never run CPU minterpolate as a fallback.
RTX 3060: target x2 (24->48, 30->60 FPS), not guaranteed real time.
